# costyl
Costyl is a python library to facilitate source code authorship attribution via stylometric analysis powered by machine learning.

*The code in this repository is largely based on the code done by myself and [Andrew](https://github.com/AndrewLFL) available at [this repository](https://github.com/Jbernardiss/codeStylometryResearch)*
